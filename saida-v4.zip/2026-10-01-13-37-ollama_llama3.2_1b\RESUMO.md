# Piloto do laboratório de agentes

Cérebro: `ollama:llama3.2:1b` · idiomas: pt, en, zh, hi, ar · duração: 3.5 min · chamadas: 3294 (0 falhas) · latência média: 0.06 s · tokens: 1070422 de entrada, 38350 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.15 | 0.11 | -0.04 |
| en | 0.25 | 0.15 | -0.09 |
| zh | 0.08 | 0.02 | -0.06 |
| hi | 0.02 | 0.01 | -0.01 |
| ar | 0.03 | 0.03 | -0.00 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.15 | 0.09 | -0.06 | 975 |
| bug | 0.05 | 0.06 | 0.01 | 105 |
| parsons | 0.00 | 0.00 | 0.00 | 210 |
| sort | 0.03 | 0.01 | -0.02 | 135 |

0 de 95 itens já são acertados em 95% das vezes sem notas. 2 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): l5, f3.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Δ antes→depois do degrau compara a previsão média com a verdade média nos tickets 1–3 e 4+ de cada habilidade. C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Δ previsto | Δ verdadeiro | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.654 | 0.077 | -0.14 | -0.14 | 0.540 |
| IRT | 0.640 | 0.093 | -0.13 | -0.14 | 0.548 |
| BKT | 0.544 | 0.167 | 0.01 | -0.14 | 0.473 |
| PFA | 0.618 | 0.044 | -0.03 | -0.14 | 0.529 |
| AFM | 0.424 | 0.639 | 0.64 | -0.14 | 0.579 |

292 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 17.3 | 257 |
| pt | S2 | 1.00 | 0.13 | 15.3 | 400 |
| pt | S3 | 1.00 | 0.00 | 18.4 | 308 |
| en | S1 | 1.00 | 0.00 | 17.3 | 407 |
| en | S2 | 1.00 | 0.00 | 19.5 | 413 |
| en | S3 | 1.00 | 0.00 | 17.3 | 407 |
| zh | S1 | 0.97 | 0.00 | 3.7 | 56 |
| zh | S2 | 0.95 | 0.00 | 4.0 | 143 |
| zh | S3 | 0.88 | 0.00 | 3.1 | 104 |
| hi | S1 | 1.00 | 0.13 | 17.2 | 223 |
| hi | S2 | 0.98 | 0.13 | 15.8 | 220 |
| hi | S3 | 0.96 | 0.00 | 14.3 | 309 |
| ar | S1 | 0.99 | 0.00 | 14.1 | 157 |
| ar | S2 | 0.99 | 0.00 | 13.4 | 89 |
| ar | S3 | 0.76 | 0.00 | 7.9 | 222 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 0.8 | 201280 | 8607 | 1.17× |
| en | 646 | 0.6 | 172634 | 6394 | 1.00× |
| zh | 662 | 0.7 | 194936 | 7140 | 1.13× |
| hi | 662 | 0.8 | 286262 | 9542 | 1.66× |
| ar | 662 | 0.6 | 215310 | 6667 | 1.25× |

## 5. Projeção para o estudo completo

Com a latência medida (0.06 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **0 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
