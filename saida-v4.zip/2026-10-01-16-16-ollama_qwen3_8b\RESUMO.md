# Piloto do laboratório de agentes

Cérebro: `ollama:qwen3:8b` · notas: ricas · idiomas: pt, en, zh, hi, ar · duração: 9.9 min · chamadas: 3294 (0 falhas) · latência média: 0.18 s · tokens: 1433237 de entrada, 32919 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.85 | 0.89 | 0.04 |
| en | 0.86 | 0.87 | 0.01 |
| zh | 0.83 | 0.85 | 0.02 |
| hi | 0.84 | 0.84 | 0.00 |
| ar | 0.82 | 0.87 | 0.05 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 1.00 | 0.00 | 0.00 |
| en | 1.00 | 0.00 | 0.00 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 1.00 | 0.00 | 0.00 |
| ar | 1.00 | 0.00 | 0.00 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.93 | 0.95 | 0.02 | 975 |
| bug | 0.89 | 0.86 | -0.03 | 105 |
| parsons | 0.44 | 0.43 | -0.01 | 210 |
| sort | 0.78 | 0.92 | 0.14 | 135 |

59 de 95 itens já são acertados em 95% das vezes sem notas. 7 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): r4, q1, q6, d6, m3, o2, g9.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.529 | 0.182 | -0.36 | -0.21 | 0.520 |
| IRT | 0.772 | 0.235 | -0.41 | -0.38 | 0.654 |
| BKT | 0.353 | 0.183 | -0.33 | 0.01 | 0.385 |
| PFA | 0.349 | 0.330 | -0.60 | -0.16 | 0.354 |
| AFM | 0.360 | 0.379 | -0.66 | -0.26 | 0.338 |

**Só nos itens informativos** (22 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.930 | 0.192 | 0.02 | 0.05 |
| IRT | 0.825 | 0.280 | -0.09 | 0.05 |
| BKT | 0.719 | 0.143 | 0.06 | 0.05 |
| PFA | 0.667 | 0.263 | 0.22 | 0.05 |
| AFM | 0.491 | 0.312 | 0.32 | 0.05 |

285 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 19.6 | 158 |
| pt | S2 | 1.00 | 0.00 | 24.9 | 161 |
| pt | S3 | 1.00 | 0.00 | 20.2 | 173 |
| en | S1 | 1.00 | 0.00 | 22.1 | 163 |
| en | S2 | 1.00 | 0.00 | 24.3 | 171 |
| en | S3 | 1.00 | 0.00 | 22.1 | 163 |
| zh | S1 | 0.99 | 0.00 | 7.4 | 51 |
| zh | S2 | 1.00 | 0.00 | 6.7 | 51 |
| zh | S3 | 0.97 | 0.00 | 4.7 | 53 |
| hi | S1 | 0.99 | 0.00 | 14.9 | 113 |
| hi | S2 | 0.99 | 0.13 | 16.1 | 123 |
| hi | S3 | 1.00 | 0.00 | 14.5 | 167 |
| ar | S1 | 0.98 | 0.00 | 14.6 | 108 |
| ar | S2 | 0.99 | 0.00 | 16.6 | 104 |
| ar | S3 | 0.98 | 0.00 | 15.8 | 143 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 1.8 | 231612 | 6400 | 1.16× |
| en | 646 | 1.7 | 200237 | 5680 | 1.00× |
| zh | 662 | 1.7 | 210122 | 6058 | 1.05× |
| hi | 662 | 2.8 | 539349 | 8362 | 2.69× |
| ar | 662 | 1.9 | 251917 | 6419 | 1.26× |

## 5. Projeção para o estudo completo

Com a latência medida (0.18 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
