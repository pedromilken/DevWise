# Piloto do laboratório de agentes

Cérebro: `ollama:qwen3:1.7b` · idiomas: pt, en, zh, hi, ar · duração: 4.2 min · chamadas: 3294 (0 falhas) · latência média: 0.08 s · tokens: 1269011 de entrada, 31010 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.61 | 0.64 | 0.02 |
| en | 0.63 | 0.64 | 0.01 |
| zh | 0.64 | 0.66 | 0.02 |
| hi | 0.49 | 0.55 | 0.06 |
| ar | 0.54 | 0.58 | 0.04 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.97 | 0.00 | 0.03 |
| en | 0.99 | 0.00 | 0.01 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 1.00 | 0.00 | 0.00 |
| ar | 0.98 | 0.00 | 0.02 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.73 | 0.78 | 0.05 | 975 |
| bug | 0.63 | 0.63 | 0.00 | 105 |
| parsons | 0.12 | 0.13 | 0.00 | 210 |
| sort | 0.21 | 0.16 | -0.04 | 135 |

15 de 95 itens já são acertados em 95% das vezes sem notas. 15 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v5, l2, l3, f1, q3, a4, g5, t2, t5, d4, d5, u2, o3, v8, g9.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Δ antes→depois do degrau compara a previsão média com a verdade média nos tickets 1–3 e 4+ de cada habilidade. C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Δ previsto | Δ verdadeiro | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.688 | 0.172 | -0.04 | -0.24 | 0.703 |
| IRT | 0.789 | 0.169 | -0.11 | -0.24 | 0.783 |
| BKT | 0.564 | 0.219 | 0.09 | -0.24 | 0.582 |
| PFA | 0.408 | 0.291 | 0.27 | -0.24 | 0.496 |
| AFM | 0.342 | 0.370 | 0.51 | -0.24 | 0.399 |

**Só nos itens informativos** (38 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.641 | 0.174 | 0.06 | 0.15 |
| IRT | 0.646 | 0.181 | -0.02 | 0.15 |
| BKT | 0.620 | 0.172 | 0.11 | 0.15 |
| PFA | 0.537 | 0.242 | 0.24 | 0.15 |
| AFM | 0.643 | 0.228 | 0.41 | 0.15 |

293 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.13 | 20.2 | 122 |
| pt | S2 | 1.00 | 0.38 | 21.5 | 139 |
| pt | S3 | 1.00 | 0.00 | 20.7 | 130 |
| en | S1 | 1.00 | 0.00 | 21.7 | 138 |
| en | S2 | 1.00 | 0.25 | 22.8 | 137 |
| en | S3 | 1.00 | 0.00 | 21.7 | 138 |
| zh | S1 | 1.00 | 0.00 | 4.6 | 40 |
| zh | S2 | 1.00 | 0.38 | 5.0 | 42 |
| zh | S3 | 0.99 | 0.13 | 4.8 | 49 |
| hi | S1 | 0.97 | 0.00 | 17.5 | 98 |
| hi | S2 | 0.97 | 0.13 | 20.6 | 128 |
| hi | S3 | 0.98 | 0.00 | 14.4 | 159 |
| ar | S1 | 0.98 | 0.13 | 15.9 | 101 |
| ar | S2 | 1.00 | 0.38 | 16.1 | 90 |
| ar | S3 | 0.99 | 0.00 | 14.4 | 111 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 0.8 | 209329 | 5988 | 1.14× |
| en | 646 | 0.7 | 182839 | 5505 | 1.00× |
| zh | 662 | 0.8 | 188741 | 5760 | 1.03× |
| hi | 662 | 1.1 | 458763 | 7840 | 2.51× |
| ar | 662 | 0.8 | 229339 | 5917 | 1.25× |

## 5. Projeção para o estudo completo

Com a latência medida (0.08 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
