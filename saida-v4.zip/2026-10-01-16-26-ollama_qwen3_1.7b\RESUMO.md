# Piloto do laboratório de agentes

Cérebro: `ollama:qwen3:1.7b` · notas: ricas · idiomas: pt, en, zh, hi, ar · duração: 4.6 min · chamadas: 3294 (0 falhas) · latência média: 0.08 s · tokens: 1454031 de entrada, 31175 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.64 | 0.67 | 0.03 |
| en | 0.64 | 0.65 | 0.01 |
| zh | 0.64 | 0.66 | 0.02 |
| hi | 0.49 | 0.59 | 0.10 |
| ar | 0.51 | 0.59 | 0.07 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.99 | 0.00 | 0.01 |
| en | 0.99 | 0.00 | 0.01 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 1.00 | 0.00 | 0.00 |
| ar | 0.99 | 0.00 | 0.01 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.74 | 0.78 | 0.05 | 975 |
| bug | 0.61 | 0.69 | 0.08 | 105 |
| parsons | 0.10 | 0.17 | 0.07 | 210 |
| sort | 0.21 | 0.20 | -0.01 | 135 |

14 de 95 itens já são acertados em 95% das vezes sem notas. 15 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): l3, q2, q3, q4, a3, t5, d1, d3, d4, a6, m5, u4, o2, v8, c8.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.641 | 0.188 | -0.19 | -0.07 | 0.607 |
| IRT | 0.774 | 0.193 | -0.21 | -0.18 | 0.763 |
| BKT | 0.520 | 0.223 | -0.17 | 0.11 | 0.499 |
| PFA | 0.357 | 0.312 | -0.41 | 0.03 | 0.392 |
| AFM | 0.360 | 0.331 | -0.44 | 0.15 | 0.355 |

**Só nos itens informativos** (49 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.730 | 0.193 | 0.11 | 0.40 |
| IRT | 0.729 | 0.259 | 0.02 | 0.40 |
| BKT | 0.669 | 0.118 | 0.23 | 0.40 |
| PFA | 0.665 | 0.234 | 0.27 | 0.40 |
| AFM | 0.712 | 0.201 | 0.40 | 0.40 |

290 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.25 | 22.0 | 171 |
| pt | S2 | 1.00 | 0.38 | 21.8 | 144 |
| pt | S3 | 1.00 | 0.13 | 21.0 | 137 |
| en | S1 | 1.00 | 0.13 | 21.0 | 154 |
| en | S2 | 1.00 | 0.38 | 22.0 | 153 |
| en | S3 | 1.00 | 0.13 | 21.0 | 154 |
| zh | S1 | 0.90 | 0.38 | 4.6 | 43 |
| zh | S2 | 0.95 | 0.13 | 5.8 | 48 |
| zh | S3 | 0.93 | 0.13 | 5.5 | 50 |
| hi | S1 | 0.99 | 0.13 | 16.6 | 108 |
| hi | S2 | 1.00 | 0.13 | 17.4 | 134 |
| hi | S3 | 1.00 | 0.00 | 15.1 | 162 |
| ar | S1 | 0.97 | 0.25 | 15.6 | 85 |
| ar | S2 | 0.95 | 0.13 | 18.8 | 99 |
| ar | S3 | 0.97 | 0.00 | 14.8 | 108 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 0.9 | 232805 | 6130 | 1.16× |
| en | 646 | 0.8 | 201134 | 5461 | 1.00× |
| zh | 662 | 0.8 | 215039 | 5734 | 1.07× |
| hi | 662 | 1.3 | 549472 | 8103 | 2.73× |
| ar | 662 | 0.9 | 255581 | 5747 | 1.27× |

## 5. Projeção para o estudo completo

Com a latência medida (0.08 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
