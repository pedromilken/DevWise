# Piloto do laboratório de agentes

Cérebro: `ollama:gemma3:1b` · idiomas: pt, en, zh, hi, ar · duração: 4.9 min · chamadas: 3294 (0 falhas) · latência média: 0.09 s · tokens: 924503 de entrada, 28559 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.02 | 0.01 | -0.02 |
| en | 0.04 | 0.03 | -0.01 |
| zh | 0.04 | 0.03 | -0.01 |
| hi | 0.08 | 0.04 | -0.04 |
| ar | 0.03 | 0.00 | -0.02 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.06 | 0.03 | -0.03 | 975 |
| bug | 0.00 | 0.00 | 0.00 | 105 |
| parsons | 0.00 | 0.00 | 0.00 | 210 |
| sort | 0.00 | 0.00 | 0.00 | 135 |

0 de 95 itens já são acertados em 95% das vezes sem notas. 2 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): q1, q3.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Δ antes→depois do degrau compara a previsão média com a verdade média nos tickets 1–3 e 4+ de cada habilidade. C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Δ previsto | Δ verdadeiro | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.697 | 0.086 | -0.14 | -0.02 | 0.513 |
| IRT | 0.561 | 0.106 | -0.13 | -0.02 | 0.471 |
| BKT | 0.588 | 0.161 | 0.00 | -0.02 | 0.505 |
| PFA | 0.704 | 0.053 | -0.04 | -0.02 | 0.616 |
| AFM | 0.359 | 0.629 | 0.64 | -0.02 | 0.468 |

**Só nos itens informativos** (25 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.684 | 0.131 | -0.14 | 0.34 |
| IRT | 0.531 | 0.130 | -0.14 | 0.34 |
| BKT | 0.404 | 0.108 | 0.05 | 0.34 |
| PFA | 0.741 | 0.217 | -0.02 | 0.34 |
| AFM | 0.364 | 0.166 | 0.75 | 0.34 |

295 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 18.2 | 271 |
| pt | S2 | 1.00 | 0.00 | 20.1 | 201 |
| pt | S3 | 1.00 | 0.00 | 14.5 | 161 |
| en | S1 | 1.00 | 0.00 | 21.2 | 251 |
| en | S2 | 1.00 | 0.13 | 19.5 | 277 |
| en | S3 | 1.00 | 0.00 | 21.2 | 251 |
| zh | S1 | 0.96 | 0.00 | 5.5 | 74 |
| zh | S2 | 0.88 | 0.00 | 3.4 | 100 |
| zh | S3 | 0.77 | 0.00 | 2.4 | 73 |
| hi | S1 | 0.95 | 0.00 | 18.1 | 223 |
| hi | S2 | 0.95 | 0.00 | 19.0 | 191 |
| hi | S3 | 0.85 | 0.00 | 15.7 | 240 |
| ar | S1 | 1.00 | 0.00 | 15.2 | 183 |
| ar | S2 | 0.99 | 0.00 | 15.6 | 137 |
| ar | S3 | 0.36 | 0.00 | 5.8 | 90 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 1.3 | 185476 | 5851 | 1.09× |
| en | 646 | 0.8 | 170384 | 4957 | 1.00× |
| zh | 662 | 0.9 | 174365 | 6085 | 1.02× |
| hi | 662 | 0.9 | 194502 | 6213 | 1.14× |
| ar | 662 | 0.9 | 199776 | 5453 | 1.17× |

## 5. Projeção para o estudo completo

Com a latência medida (0.09 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
