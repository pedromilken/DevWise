# Piloto do laboratório de agentes

Cérebro: `ollama:llama3.2:1b` · idiomas: pt, en, zh, hi, ar · duração: 3.5 min · chamadas: 3294 (0 falhas) · latência média: 0.06 s · tokens: 1071749 de entrada, 38843 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.24 | 0.20 | -0.04 |
| en | 0.39 | 0.32 | -0.07 |
| zh | 0.26 | 0.31 | 0.04 |
| hi | 0.24 | 0.29 | 0.05 |
| ar | 0.13 | 0.25 | 0.12 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.32 | 0.67 | 0.00 |
| en | 0.38 | 0.62 | 0.00 |
| zh | 0.18 | 0.82 | 0.00 |
| hi | 0.03 | 0.95 | 0.01 |
| ar | 0.12 | 0.88 | 0.00 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.34 | 0.38 | 0.04 | 975 |
| bug | 0.10 | 0.06 | -0.05 | 105 |
| parsons | 0.01 | 0.01 | 0.00 | 210 |
| sort | 0.07 | 0.01 | -0.06 | 135 |

0 de 95 itens já são acertados em 95% das vezes sem notas. 14 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v4, v5, c2, c4, a2, g4, t4, t5, m1, m2, o5, v7, q11, g10.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Δ antes→depois do degrau compara a previsão média com a verdade média nos tickets 1–3 e 4+ de cada habilidade. C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Δ previsto | Δ verdadeiro | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.675 | 0.104 | -0.13 | -0.10 | 0.637 |
| IRT | 0.712 | 0.085 | -0.16 | -0.10 | 0.704 |
| BKT | 0.613 | 0.184 | 0.02 | -0.10 | 0.550 |
| PFA | 0.452 | 0.183 | 0.14 | -0.10 | 0.459 |
| AFM | 0.439 | 0.471 | 0.64 | -0.10 | 0.466 |

**Só nos itens informativos** (36 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.562 | 0.190 | -0.35 | 0.15 |
| IRT | 0.503 | 0.163 | -0.27 | 0.15 |
| BKT | 0.591 | 0.187 | -0.18 | 0.15 |
| PFA | 0.602 | 0.264 | -0.02 | 0.15 |
| AFM | 0.526 | 0.241 | 0.69 | 0.15 |

287 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 20.2 | 292 |
| pt | S2 | 1.00 | 0.00 | 15.6 | 313 |
| pt | S3 | 1.00 | 0.00 | 19.2 | 325 |
| en | S1 | 1.00 | 0.00 | 19.3 | 368 |
| en | S2 | 1.00 | 0.25 | 20.8 | 424 |
| en | S3 | 1.00 | 0.00 | 19.3 | 368 |
| zh | S1 | 0.97 | 0.13 | 2.6 | 61 |
| zh | S2 | 0.90 | 0.13 | 4.3 | 208 |
| zh | S3 | 0.85 | 0.00 | 2.3 | 117 |
| hi | S1 | 0.96 | 0.00 | 15.6 | 163 |
| hi | S2 | 0.98 | 0.13 | 18.8 | 282 |
| hi | S3 | 0.99 | 0.00 | 14.2 | 271 |
| ar | S1 | 0.95 | 0.13 | 13.2 | 106 |
| ar | S2 | 0.99 | 0.13 | 15.2 | 164 |
| ar | S3 | 0.82 | 0.00 | 10.1 | 358 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 0.8 | 201602 | 8235 | 1.17× |
| en | 646 | 0.6 | 172495 | 6325 | 1.00× |
| zh | 662 | 0.7 | 194724 | 7886 | 1.13× |
| hi | 662 | 0.8 | 287227 | 9348 | 1.67× |
| ar | 662 | 0.7 | 215701 | 7049 | 1.25× |

## 5. Projeção para o estudo completo

Com a latência medida (0.06 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **0 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
