# Piloto do laboratório de agentes

Cérebro: `ollama:qwen3:1.7b` · idiomas: pt, en, zh, hi, ar · duração: 4.5 min · chamadas: 3294 (0 falhas) · latência média: 0.08 s · tokens: 1261299 de entrada, 31536 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.63 | 0.65 | 0.02 |
| en | 0.62 | 0.63 | 0.01 |
| zh | 0.65 | 0.64 | -0.01 |
| hi | 0.50 | 0.58 | 0.08 |
| ar | 0.52 | 0.56 | 0.04 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.73 | 0.77 | 0.04 | 975 |
| bug | 0.61 | 0.65 | 0.04 | 105 |
| parsons | 0.11 | 0.15 | 0.04 | 210 |
| sort | 0.21 | 0.16 | -0.04 | 135 |

13 de 95 itens já são acertados em 95% das vezes sem notas. 10 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v4, l3, q1, q3, d1, d4, u5, o2, v8, g9.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Δ antes→depois do degrau compara a previsão média com a verdade média nos tickets 1–3 e 4+ de cada habilidade. C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Δ previsto | Δ verdadeiro | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.616 | 0.191 | -0.02 | -0.15 | 0.655 |
| IRT | 0.774 | 0.186 | -0.11 | -0.15 | 0.760 |
| BKT | 0.507 | 0.240 | 0.13 | -0.15 | 0.555 |
| PFA | 0.388 | 0.286 | 0.34 | -0.15 | 0.468 |
| AFM | 0.335 | 0.350 | 0.53 | -0.15 | 0.395 |

**Só nos itens informativos** (35 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.375 | 0.237 | -0.01 | -0.00 |
| IRT | 0.576 | 0.227 | -0.12 | -0.00 |
| BKT | 0.414 | 0.229 | 0.25 | -0.00 |
| PFA | 0.301 | 0.301 | 0.45 | -0.00 |
| AFM | 0.395 | 0.293 | 0.59 | -0.00 |

291 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.25 | 15.8 | 154 |
| pt | S2 | 1.00 | 0.25 | 16.0 | 137 |
| pt | S3 | 1.00 | 0.00 | 18.3 | 155 |
| en | S1 | 1.00 | 0.13 | 20.0 | 129 |
| en | S2 | 1.00 | 0.50 | 22.6 | 134 |
| en | S3 | 1.00 | 0.13 | 20.0 | 129 |
| zh | S1 | 0.98 | 0.00 | 4.0 | 38 |
| zh | S2 | 0.99 | 0.00 | 4.1 | 47 |
| zh | S3 | 0.92 | 0.00 | 6.0 | 43 |
| hi | S1 | 0.98 | 0.00 | 17.8 | 106 |
| hi | S2 | 0.97 | 0.38 | 18.8 | 116 |
| hi | S3 | 1.00 | 0.00 | 15.3 | 180 |
| ar | S1 | 0.99 | 0.00 | 18.1 | 97 |
| ar | S2 | 0.97 | 0.13 | 21.0 | 96 |
| ar | S3 | 0.99 | 0.00 | 18.0 | 130 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 1.0 | 212633 | 6208 | 1.21× |
| en | 646 | 0.8 | 176155 | 5555 | 1.00× |
| zh | 662 | 0.8 | 188388 | 5752 | 1.07× |
| hi | 662 | 1.2 | 458840 | 8026 | 2.60× |
| ar | 662 | 0.8 | 225283 | 5995 | 1.28× |

## 5. Projeção para o estudo completo

Com a latência medida (0.08 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
