# Piloto do laboratório de agentes

Cérebro: `ollama:gemma3:4b` · notas: ricas · idiomas: pt, en, zh, hi, ar · duração: 9.4 min · chamadas: 3294 (0 falhas) · latência média: 0.17 s · tokens: 1099620 de entrada, 31309 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.60 | 0.71 | 0.10 |
| en | 0.69 | 0.75 | 0.07 |
| zh | 0.63 | 0.72 | 0.09 |
| hi | 0.55 | 0.66 | 0.11 |
| ar | 0.53 | 0.72 | 0.19 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.87 | 0.13 | 0.00 |
| en | 1.00 | 0.00 | 0.00 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 0.79 | 0.21 | 0.00 |
| ar | 1.00 | 0.00 | 0.00 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.72 | 0.82 | 0.10 | 975 |
| bug | 0.68 | 0.88 | 0.20 | 105 |
| parsons | 0.21 | 0.28 | 0.06 | 210 |
| sort | 0.30 | 0.50 | 0.19 | 135 |

25 de 95 itens já são acertados em 95% das vezes sem notas. 26 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): c1, c2, c4, l2, l3, f2, q5, g2, t4, t5, d3, d4, d5, q6, a6, d6, m2, m3, m5, u5, o2, v6, c6, c7, c10, q7.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.548 | 0.197 | -0.22 | -0.11 | 0.555 |
| IRT | 0.690 | 0.213 | -0.24 | -0.25 | 0.646 |
| BKT | 0.433 | 0.221 | -0.20 | 0.10 | 0.464 |
| PFA | 0.392 | 0.307 | -0.44 | -0.03 | 0.405 |
| AFM | 0.404 | 0.308 | -0.47 | 0.02 | 0.397 |

**Só nos itens informativos** (82 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.461 | 0.192 | 0.06 | 0.24 |
| IRT | 0.445 | 0.231 | -0.01 | 0.24 |
| BKT | 0.454 | 0.164 | 0.17 | 0.24 |
| PFA | 0.473 | 0.232 | 0.30 | 0.24 |
| AFM | 0.527 | 0.224 | 0.41 | 0.24 |

290 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 20.8 | 241 |
| pt | S2 | 1.00 | 0.00 | 20.9 | 234 |
| pt | S3 | 1.00 | 0.00 | 21.2 | 264 |
| en | S1 | 1.00 | 0.00 | 19.4 | 241 |
| en | S2 | 1.00 | 0.00 | 18.9 | 246 |
| en | S3 | 1.00 | 0.00 | 19.4 | 241 |
| zh | S1 | 0.98 | 0.00 | 4.6 | 75 |
| zh | S2 | 0.99 | 0.00 | 5.0 | 77 |
| zh | S3 | 0.99 | 0.00 | 5.6 | 71 |
| hi | S1 | 0.99 | 0.00 | 21.0 | 222 |
| hi | S2 | 0.98 | 0.00 | 24.3 | 228 |
| hi | S3 | 0.99 | 0.00 | 19.2 | 256 |
| ar | S1 | 0.97 | 0.00 | 18.5 | 169 |
| ar | S2 | 0.95 | 0.00 | 17.8 | 176 |
| ar | S3 | 0.98 | 0.00 | 19.6 | 207 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 2.0 | 220967 | 6589 | 1.08× |
| en | 646 | 1.7 | 203840 | 5610 | 1.00× |
| zh | 662 | 1.8 | 207387 | 6176 | 1.02× |
| hi | 662 | 1.9 | 232784 | 6470 | 1.14× |
| ar | 662 | 2.0 | 234642 | 6464 | 1.15× |

## 5. Projeção para o estudo completo

Com a latência medida (0.17 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
