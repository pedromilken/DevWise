# Piloto do laboratório de agentes

Cérebro: `ollama:gemma3:1b` · idiomas: pt, en, zh, hi, ar · duração: 4.5 min · chamadas: 3294 (0 falhas) · latência média: 0.08 s · tokens: 933505 de entrada, 28601 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.34 | 0.36 | 0.03 |
| en | 0.35 | 0.38 | 0.03 |
| zh | 0.34 | 0.38 | 0.03 |
| hi | 0.38 | 0.33 | -0.05 |
| ar | 0.29 | 0.33 | 0.04 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.05 | 0.93 | 0.03 |
| en | 0.06 | 0.90 | 0.04 |
| zh | 0.08 | 0.89 | 0.03 |
| hi | 0.19 | 0.79 | 0.02 |
| ar | 0.11 | 0.87 | 0.02 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.47 | 0.51 | 0.04 | 975 |
| bug | 0.22 | 0.10 | -0.12 | 105 |
| parsons | 0.01 | 0.01 | 0.00 | 210 |
| sort | 0.00 | 0.00 | 0.00 | 135 |

0 de 95 itens já são acertados em 95% das vezes sem notas. 17 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v3, c1, c2, f2, f3, k3, r1, q1, a2, a3, a5, g1, g4, d1, d5, u1, v7.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Δ antes→depois do degrau compara a previsão média com a verdade média nos tickets 1–3 e 4+ de cada habilidade. C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Δ previsto | Δ verdadeiro | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.663 | 0.124 | -0.06 | -0.09 | 0.631 |
| IRT | 0.695 | 0.111 | -0.12 | -0.09 | 0.699 |
| BKT | 0.620 | 0.183 | 0.08 | -0.09 | 0.562 |
| PFA | 0.456 | 0.213 | 0.19 | -0.09 | 0.450 |
| AFM | 0.438 | 0.413 | 0.60 | -0.09 | 0.406 |

**Só nos itens informativos** (41 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.483 | 0.144 | -0.09 | 0.20 |
| IRT | 0.469 | 0.150 | -0.18 | 0.20 |
| BKT | 0.534 | 0.113 | 0.12 | 0.20 |
| PFA | 0.506 | 0.182 | 0.17 | 0.20 |
| AFM | 0.488 | 0.157 | 0.65 | 0.20 |

288 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 17.1 | 233 |
| pt | S2 | 1.00 | 0.13 | 20.9 | 192 |
| pt | S3 | 1.00 | 0.00 | 16.1 | 199 |
| en | S1 | 1.00 | 0.00 | 20.7 | 234 |
| en | S2 | 1.00 | 0.00 | 19.8 | 217 |
| en | S3 | 1.00 | 0.00 | 20.7 | 234 |
| zh | S1 | 0.96 | 0.00 | 3.9 | 76 |
| zh | S2 | 0.99 | 0.00 | 4.9 | 82 |
| zh | S3 | 0.97 | 0.00 | 3.6 | 62 |
| hi | S1 | 0.99 | 0.00 | 14.8 | 237 |
| hi | S2 | 0.99 | 0.00 | 15.6 | 204 |
| hi | S3 | 0.96 | 0.00 | 16.4 | 237 |
| ar | S1 | 0.91 | 0.00 | 13.5 | 190 |
| ar | S2 | 0.98 | 0.00 | 12.5 | 154 |
| ar | S3 | 0.86 | 0.00 | 14.1 | 163 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 0.9 | 185616 | 5749 | 1.06× |
| en | 646 | 0.8 | 175354 | 4952 | 1.00× |
| zh | 662 | 0.9 | 178254 | 6059 | 1.02× |
| hi | 662 | 0.9 | 194494 | 6150 | 1.11× |
| ar | 662 | 0.9 | 199787 | 5691 | 1.14× |

## 5. Projeção para o estudo completo

Com a latência medida (0.08 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
