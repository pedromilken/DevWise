# Piloto do laboratório de agentes

Cérebro: `ollama:gemma3:4b` · idiomas: pt, en, zh, hi, ar · duração: 8.9 min · chamadas: 3294 (0 falhas) · latência média: 0.16 s · tokens: 988052 de entrada, 31134 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.49 | 0.48 | -0.01 |
| en | 0.70 | 0.73 | 0.04 |
| zh | 0.60 | 0.66 | 0.06 |
| hi | 0.54 | 0.19 | -0.35 |
| ar | 0.51 | 0.65 | 0.14 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.66 | 0.61 | -0.05 | 975 |
| bug | 0.69 | 0.75 | 0.07 | 105 |
| parsons | 0.25 | 0.20 | -0.05 | 210 |
| sort | 0.28 | 0.39 | 0.11 | 135 |

11 de 95 itens já são acertados em 95% das vezes sem notas. 14 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v2, k4, r4, t5, d4, d5, q6, m5, u5, o4, c7, c10, q7, g9.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Δ antes→depois do degrau compara a previsão média com a verdade média nos tickets 1–3 e 4+ de cada habilidade. C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Δ previsto | Δ verdadeiro | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.651 | 0.192 | 0.01 | -0.18 | 0.685 |
| IRT | 0.776 | 0.182 | -0.08 | -0.18 | 0.758 |
| BKT | 0.515 | 0.251 | 0.14 | -0.18 | 0.559 |
| PFA | 0.354 | 0.302 | 0.37 | -0.18 | 0.474 |
| AFM | 0.295 | 0.364 | 0.52 | -0.18 | 0.372 |

**Só nos itens informativos** (35 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.377 | 0.236 | 0.01 | 0.35 |
| IRT | 0.466 | 0.246 | -0.00 | 0.35 |
| BKT | 0.371 | 0.231 | 0.03 | 0.35 |
| PFA | 0.444 | 0.240 | 0.22 | 0.35 |
| AFM | 0.562 | 0.249 | 0.37 | 0.35 |

293 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 20.6 | 224 |
| pt | S2 | 1.00 | 0.00 | 20.6 | 234 |
| pt | S3 | 1.00 | 0.00 | 23.7 | 245 |
| en | S1 | 1.00 | 0.00 | 19.3 | 249 |
| en | S2 | 1.00 | 0.13 | 22.0 | 246 |
| en | S3 | 1.00 | 0.00 | 19.3 | 249 |
| zh | S1 | 0.96 | 0.00 | 4.4 | 81 |
| zh | S2 | 0.96 | 0.00 | 4.6 | 83 |
| zh | S3 | 0.97 | 0.00 | 4.9 | 72 |
| hi | S1 | 0.98 | 0.00 | 18.8 | 219 |
| hi | S2 | 0.98 | 0.13 | 20.4 | 206 |
| hi | S3 | 1.00 | 0.00 | 18.7 | 248 |
| ar | S1 | 0.99 | 0.13 | 16.0 | 182 |
| ar | S2 | 1.00 | 0.00 | 19.0 | 187 |
| ar | S3 | 1.00 | 0.00 | 20.6 | 200 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 662 | 1.9 | 196142 | 6422 | 1.05× |
| en | 646 | 1.6 | 187355 | 5659 | 1.00× |
| zh | 662 | 1.7 | 185168 | 6061 | 0.99× |
| hi | 662 | 1.8 | 200523 | 6453 | 1.07× |
| ar | 662 | 1.8 | 218864 | 6539 | 1.17× |

## 5. Projeção para o estudo completo

Com a latência medida (0.16 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
