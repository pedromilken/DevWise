# Piloto do laboratório de agentes

Cérebro: `ollama:qwen3:8b` · idiomas: pt, en, zh, hi, ar · duração: 5.7 min · chamadas: 1704 (0 falhas) · latência média: 0.20 s · tokens: 1166644 de entrada, 21121 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.81 | 0.86 | 0.05 |
| en | 0.83 | 0.83 | 0.01 |
| zh | 0.78 | 0.83 | 0.05 |
| hi | 0.76 | 0.83 | 0.07 |
| ar | 0.79 | 0.84 | 0.05 |

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Δ antes→depois do degrau compara a previsão média com a verdade média nos tickets 1–3 e 4+ de cada habilidade. C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Δ previsto | Δ verdadeiro | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.769 | 0.180 | 0.12 | 0.08 | 0.590 |
| IRT | 0.841 | 0.244 | -0.02 | 0.08 | 0.702 |
| BKT | 0.619 | 0.174 | 0.28 | 0.08 | 0.514 |
| PFA | 0.589 | 0.306 | 0.37 | 0.08 | 0.460 |
| AFM | 0.627 | 0.327 | 0.34 | 0.08 | 0.359 |

112 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Palavras |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 27.8 | 25 |
| pt | S2 | 1.00 | 0.00 | 24.8 | 27 |
| pt | S3 | 1.00 | 0.00 | 26.7 | 29 |
| en | S1 | 1.00 | 0.00 | 24.8 | 26 |
| en | S2 | 1.00 | 0.00 | 24.7 | 27 |
| en | S3 | 1.00 | 0.00 | 24.8 | 26 |
| zh | S1 | 0.98 | 0.13 | 6.8 | 2 |
| zh | S2 | 0.95 | 0.25 | 7.5 | 2 |
| zh | S3 | 0.99 | 0.00 | 5.0 | 1 |
| hi | S1 | 0.99 | 0.00 | 17.7 | 22 |
| hi | S2 | 0.99 | 0.13 | 22.8 | 20 |
| hi | S3 | 0.99 | 0.00 | 18.3 | 33 |
| ar | S1 | 0.98 | 0.00 | 17.3 | 19 |
| ar | S2 | 0.99 | 0.00 | 17.6 | 20 |
| ar | S3 | 0.99 | 0.00 | 20.7 | 25 |

## 4. Projeção para o estudo completo

Com a latência medida (0.20 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **2 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
