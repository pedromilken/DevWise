# Piloto do laboratório de agentes

Cérebro: `ollama:qwen3:1.7b` · notas: ricas · dialeto cifrado: sim · idiomas: pt, en, zh, hi, ar · duração: 4.9 min · chamadas: 3394 (0 falhas) · latência média: 0.09 s · tokens: 1628982 de entrada, 32040 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.57 | 0.58 | 0.01 |
| en | 0.56 | 0.63 | 0.06 |
| zh | 0.59 | 0.65 | 0.06 |
| hi | 0.44 | 0.57 | 0.14 |
| ar | 0.46 | 0.55 | 0.09 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.39 | 0.47 | 0.09 |
| engenharia de software | 0.62 | 0.68 | 0.06 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.98 | 0.00 | 0.02 |
| en | 0.99 | 0.00 | 0.01 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 1.00 | 0.00 | 0.00 |
| ar | 0.99 | 0.00 | 0.01 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.64 | 0.76 | 0.12 | 975 |
| bug | 0.70 | 0.52 | -0.17 | 105 |
| parsons | 0.10 | 0.15 | 0.05 | 210 |
| sort | 0.20 | 0.15 | -0.05 | 135 |

14 de 95 itens já são acertados em 95% das vezes sem notas. 27 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v1, v2, v4, c1, c2, c4, f1, f3, k1, k2, r4, q2, q3, q4, q5, g5, t2, t5, d1, d4, d5, g6, u2, o2, o4, v7, c8.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.680 | 0.174 | -0.17 | 0.08 | 0.721 |
| IRT | 0.794 | 0.151 | -0.20 | -0.02 | 0.787 |
| BKT | 0.602 | 0.218 | -0.15 | 0.22 | 0.611 |
| PFA | 0.383 | 0.333 | -0.42 | 0.27 | 0.489 |
| AFM | 0.283 | 0.512 | -0.44 | 0.51 | 0.365 |

**Só nos itens informativos** (85 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.537 | 0.194 | -0.02 | 0.16 |
| IRT | 0.513 | 0.211 | -0.09 | 0.16 |
| BKT | 0.559 | 0.153 | 0.06 | 0.16 |
| PFA | 0.562 | 0.223 | 0.39 | 0.16 |
| AFM | 0.549 | 0.279 | 0.63 | 0.16 |

**Programação** (125 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | 0.11 | 0.11 | 0.157 |
| IRT | 0.10 | 0.06 | 0.134 |
| BKT | 0.12 | 0.26 | 0.215 |
| PFA | -0.27 | 0.32 | 0.312 |
| AFM | -0.24 | 0.63 | 0.557 |

**Engenharia de software** (270 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.22 | 0.07 | 0.181 |
| IRT | -0.25 | -0.06 | 0.159 |
| BKT | -0.19 | 0.20 | 0.219 |
| PFA | -0.44 | 0.24 | 0.342 |
| AFM | -0.47 | 0.45 | 0.491 |

395 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.13 | 23.1 | 161 |
| pt | S2 | 1.00 | 0.38 | 20.8 | 165 |
| pt | S3 | 1.00 | 0.13 | 21.7 | 131 |
| en | S1 | 1.00 | 0.13 | 22.1 | 149 |
| en | S2 | 1.00 | 0.38 | 25.0 | 136 |
| en | S3 | 1.00 | 0.13 | 22.1 | 149 |
| zh | S1 | 0.97 | 0.25 | 3.5 | 39 |
| zh | S2 | 0.98 | 0.13 | 5.6 | 39 |
| zh | S3 | 0.95 | 0.13 | 4.4 | 45 |
| hi | S1 | 1.00 | 0.25 | 16.4 | 83 |
| hi | S2 | 0.99 | 0.25 | 22.0 | 116 |
| hi | S3 | 1.00 | 0.00 | 19.6 | 167 |
| ar | S1 | 0.96 | 0.25 | 15.4 | 79 |
| ar | S2 | 0.95 | 0.13 | 16.1 | 102 |
| ar | S3 | 0.85 | 0.00 | 15.6 | 103 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 0.9 | 267318 | 6553 | 1.17× |
| en | 666 | 0.8 | 229414 | 5785 | 1.00× |
| zh | 682 | 0.9 | 239393 | 5848 | 1.04× |
| hi | 682 | 1.4 | 608771 | 7909 | 2.65× |
| ar | 682 | 0.9 | 284086 | 5945 | 1.24× |

## 5. Projeção para o estudo completo

Com a latência medida (0.09 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
