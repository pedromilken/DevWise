# Piloto do laboratório de agentes

Cérebro: `ollama:qwen3:8b` · notas: ricas · dialeto cifrado: não · idiomas: pt, en, zh, hi, ar · duração: 10.1 min · chamadas: 3394 (0 falhas) · latência média: 0.18 s · tokens: 1480152 de entrada, 34148 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.86 | 0.88 | 0.02 |
| en | 0.87 | 0.88 | 0.01 |
| zh | 0.81 | 0.84 | 0.03 |
| hi | 0.82 | 0.83 | 0.01 |
| ar | 0.80 | 0.88 | 0.08 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.80 | 0.80 | 0.00 |
| engenharia de software | 0.86 | 0.91 | 0.05 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 1.00 | 0.00 | 0.00 |
| en | 1.00 | 0.00 | 0.00 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 1.00 | 0.00 | 0.00 |
| ar | 1.00 | 0.00 | 0.00 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.93 | 0.96 | 0.02 | 975 |
| bug | 0.89 | 0.84 | -0.05 | 105 |
| parsons | 0.36 | 0.40 | 0.03 | 210 |
| sort | 0.79 | 0.90 | 0.12 | 135 |

61 de 95 itens já são acertados em 95% das vezes sem notas. 10 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): r4, q1, g5, q6, g6, m3, o2, v6, q8, g9.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.537 | 0.206 | -0.39 | -0.19 | 0.539 |
| IRT | 0.678 | 0.258 | -0.43 | -0.37 | 0.622 |
| BKT | 0.424 | 0.205 | -0.36 | 0.04 | 0.438 |
| PFA | 0.343 | 0.359 | -0.63 | -0.11 | 0.418 |
| AFM | 0.354 | 0.405 | -0.67 | -0.21 | 0.396 |

**Só nos itens informativos** (41 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.621 | 0.196 | 0.16 | 0.18 |
| IRT | 0.580 | 0.259 | 0.02 | 0.18 |
| BKT | 0.426 | 0.206 | 0.32 | 0.18 |
| PFA | 0.442 | 0.229 | 0.39 | 0.18 |
| AFM | 0.415 | 0.264 | 0.32 | 0.18 |

**Programação** (149 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.43 | -0.10 | 0.195 |
| IRT | -0.46 | -0.26 | 0.237 |
| BKT | -0.41 | 0.14 | 0.225 |
| PFA | -0.69 | 0.02 | 0.376 |
| AFM | -0.74 | -0.10 | 0.420 |

**Engenharia de software** (227 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.37 | -0.26 | 0.214 |
| IRT | -0.41 | -0.44 | 0.272 |
| BKT | -0.33 | -0.04 | 0.193 |
| PFA | -0.59 | -0.21 | 0.348 |
| AFM | -0.63 | -0.29 | 0.394 |

376 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.13 | 21.8 | 153 |
| pt | S2 | 1.00 | 0.13 | 24.5 | 153 |
| pt | S3 | 1.00 | 0.13 | 22.9 | 163 |
| en | S1 | 1.00 | 0.00 | 27.0 | 161 |
| en | S2 | 1.00 | 0.00 | 25.7 | 164 |
| en | S3 | 1.00 | 0.00 | 27.0 | 161 |
| zh | S1 | 0.97 | 0.00 | 7.1 | 50 |
| zh | S2 | 0.92 | 0.13 | 6.7 | 51 |
| zh | S3 | 0.95 | 0.00 | 7.0 | 55 |
| hi | S1 | 1.00 | 0.00 | 20.8 | 116 |
| hi | S2 | 1.00 | 0.13 | 14.9 | 124 |
| hi | S3 | 1.00 | 0.00 | 16.2 | 191 |
| ar | S1 | 0.99 | 0.00 | 15.9 | 114 |
| ar | S2 | 0.99 | 0.00 | 20.1 | 113 |
| ar | S3 | 0.99 | 0.00 | 18.7 | 128 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 1.9 | 242256 | 6615 | 1.17× |
| en | 666 | 1.7 | 206463 | 5881 | 1.00× |
| zh | 682 | 1.8 | 217710 | 6323 | 1.05× |
| hi | 682 | 2.9 | 555296 | 8711 | 2.69× |
| ar | 682 | 1.9 | 258427 | 6618 | 1.25× |

## 5. Projeção para o estudo completo

Com a latência medida (0.18 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
