# Piloto do laboratório de agentes

Cérebro: `ollama:qwen3:8b` · notas: ricas · dialeto cifrado: sim · idiomas: pt, en, zh, hi, ar · duração: 10.4 min · chamadas: 3394 (0 falhas) · latência média: 0.18 s · tokens: 1587519 de entrada, 34340 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.80 | 0.85 | 0.05 |
| en | 0.84 | 0.87 | 0.04 |
| zh | 0.77 | 0.84 | 0.07 |
| hi | 0.69 | 0.81 | 0.12 |
| ar | 0.70 | 0.89 | 0.20 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.62 | 0.77 | 0.15 |
| engenharia de software | 0.86 | 0.92 | 0.05 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 1.00 | 0.00 | 0.00 |
| en | 1.00 | 0.00 | 0.00 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 1.00 | 0.00 | 0.00 |
| ar | 1.00 | 0.00 | 0.00 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.86 | 0.94 | 0.08 | 975 |
| bug | 0.66 | 0.86 | 0.20 | 105 |
| parsons | 0.34 | 0.45 | 0.10 | 210 |
| sort | 0.79 | 0.90 | 0.12 | 135 |

45 de 95 itens já são acertados em 95% das vezes sem notas. 21 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v2, c3, c4, c5, l3, f1, f3, f5, k2, k5, r2, q1, q6, g6, m3, o2, v6, v8, v9, c6, g9.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.694 | 0.190 | -0.30 | -0.15 | 0.656 |
| IRT | 0.758 | 0.235 | -0.33 | -0.30 | 0.703 |
| BKT | 0.598 | 0.200 | -0.26 | 0.05 | 0.565 |
| PFA | 0.388 | 0.325 | -0.52 | -0.03 | 0.559 |
| AFM | 0.293 | 0.397 | -0.56 | -0.03 | 0.274 |

**Só nos itens informativos** (95 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.635 | 0.187 | 0.06 | 0.14 |
| IRT | 0.520 | 0.224 | -0.04 | 0.14 |
| BKT | 0.674 | 0.177 | 0.14 | 0.14 |
| PFA | 0.476 | 0.242 | 0.42 | 0.14 |
| AFM | 0.436 | 0.303 | 0.51 | 0.14 |

**Programação** (178 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.23 | -0.03 | 0.197 |
| IRT | -0.24 | -0.13 | 0.213 |
| BKT | -0.22 | 0.17 | 0.236 |
| PFA | -0.48 | 0.16 | 0.347 |
| AFM | -0.50 | 0.26 | 0.442 |

**Engenharia de software** (201 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.34 | -0.30 | 0.185 |
| IRT | -0.38 | -0.49 | 0.255 |
| BKT | -0.29 | -0.10 | 0.168 |
| PFA | -0.55 | -0.26 | 0.306 |
| AFM | -0.60 | -0.38 | 0.358 |

379 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 24.2 | 149 |
| pt | S2 | 1.00 | 0.00 | 20.9 | 155 |
| pt | S3 | 1.00 | 0.00 | 22.6 | 181 |
| en | S1 | 1.00 | 0.00 | 25.3 | 165 |
| en | S2 | 1.00 | 0.00 | 24.4 | 163 |
| en | S3 | 1.00 | 0.00 | 25.3 | 165 |
| zh | S1 | 1.00 | 0.00 | 4.3 | 49 |
| zh | S2 | 1.00 | 0.00 | 8.2 | 50 |
| zh | S3 | 0.99 | 0.00 | 4.1 | 55 |
| hi | S1 | 1.00 | 0.00 | 17.1 | 103 |
| hi | S2 | 0.98 | 0.13 | 18.4 | 129 |
| hi | S3 | 1.00 | 0.00 | 19.8 | 176 |
| ar | S1 | 0.96 | 0.00 | 19.5 | 109 |
| ar | S2 | 0.98 | 0.00 | 19.0 | 106 |
| ar | S3 | 0.97 | 0.00 | 22.0 | 125 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 2.0 | 260155 | 6839 | 1.17× |
| en | 666 | 1.7 | 222197 | 5860 | 1.00× |
| zh | 682 | 1.8 | 233868 | 6339 | 1.05× |
| hi | 682 | 2.9 | 596793 | 8632 | 2.69× |
| ar | 682 | 1.9 | 274506 | 6670 | 1.24× |

## 5. Projeção para o estudo completo

Com a latência medida (0.18 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
