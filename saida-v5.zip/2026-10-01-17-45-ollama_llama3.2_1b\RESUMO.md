# Piloto do laboratório de agentes

Cérebro: `ollama:llama3.2:1b` · notas: ricas · dialeto cifrado: não · idiomas: pt, en, zh, hi, ar · duração: 3.6 min · chamadas: 3394 (0 falhas) · latência média: 0.06 s · tokens: 1361028 de entrada, 37031 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.26 | 0.30 | 0.04 |
| en | 0.36 | 0.29 | -0.08 |
| zh | 0.24 | 0.28 | 0.05 |
| hi | 0.22 | 0.24 | 0.01 |
| ar | 0.18 | 0.23 | 0.05 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.23 | 0.17 | -0.06 |
| engenharia de software | 0.27 | 0.34 | 0.07 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.24 | 0.76 | 0.00 |
| en | 0.26 | 0.73 | 0.01 |
| zh | 0.13 | 0.87 | 0.00 |
| hi | 0.03 | 0.96 | 0.01 |
| ar | 0.09 | 0.91 | 0.00 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.34 | 0.38 | 0.03 | 975 |
| bug | 0.14 | 0.09 | -0.06 | 105 |
| parsons | 0.01 | 0.02 | 0.01 | 210 |
| sort | 0.08 | 0.00 | -0.08 | 135 |

0 de 95 itens já são acertados em 95% das vezes sem notas. 13 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): l5, q5, a1, a2, g3, t1, t4, t5, d1, m2, v7, q10, q11.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.705 | 0.087 | 0.11 | 0.14 | 0.674 |
| IRT | 0.745 | 0.081 | 0.11 | 0.13 | 0.704 |
| BKT | 0.652 | 0.151 | 0.10 | 0.27 | 0.623 |
| PFA | 0.419 | 0.142 | -0.14 | 0.16 | 0.410 |
| AFM | 0.324 | 0.617 | -0.11 | 0.75 | 0.483 |

**Só nos itens informativos** (35 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.551 | 0.161 | -0.07 | 0.14 |
| IRT | 0.541 | 0.170 | -0.08 | 0.14 |
| BKT | 0.618 | 0.141 | -0.01 | 0.14 |
| PFA | 0.465 | 0.198 | 0.08 | 0.14 |
| AFM | 0.288 | 0.283 | 0.61 | 0.14 |

**Programação** (118 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | 0.24 | 0.19 | 0.108 |
| IRT | 0.24 | 0.22 | 0.120 |
| BKT | 0.19 | 0.34 | 0.197 |
| PFA | -0.10 | 0.11 | 0.100 |
| AFM | -0.09 | 0.79 | 0.664 |

**Engenharia de software** (265 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | 0.06 | 0.11 | 0.078 |
| IRT | 0.07 | 0.08 | 0.064 |
| BKT | 0.08 | 0.24 | 0.131 |
| PFA | -0.15 | 0.18 | 0.161 |
| AFM | -0.12 | 0.74 | 0.596 |

383 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 15.7 | 264 |
| pt | S2 | 1.00 | 0.00 | 17.7 | 309 |
| pt | S3 | 1.00 | 0.00 | 16.1 | 298 |
| en | S1 | 1.00 | 0.00 | 18.8 | 332 |
| en | S2 | 1.00 | 0.00 | 17.6 | 560 |
| en | S3 | 1.00 | 0.00 | 18.8 | 332 |
| zh | S1 | 0.89 | 0.13 | 3.9 | 85 |
| zh | S2 | 0.93 | 0.00 | 4.3 | 162 |
| zh | S3 | 0.88 | 0.00 | 3.2 | 94 |
| hi | S1 | 0.99 | 0.25 | 15.8 | 199 |
| hi | S2 | 0.97 | 0.13 | 18.4 | 322 |
| hi | S3 | 0.99 | 0.00 | 15.4 | 267 |
| ar | S1 | 0.99 | 0.00 | 14.0 | 170 |
| ar | S2 | 0.95 | 0.00 | 15.0 | 209 |
| ar | S3 | 0.64 | 0.00 | 10.4 | 147 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 0.8 | 255486 | 8120 | 1.19× |
| en | 666 | 0.6 | 214524 | 6105 | 1.00× |
| zh | 682 | 0.7 | 242725 | 6837 | 1.13× |
| hi | 682 | 0.8 | 373692 | 9405 | 1.74× |
| ar | 682 | 0.7 | 274601 | 6564 | 1.28× |

## 5. Projeção para o estudo completo

Com a latência medida (0.06 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **0 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
