# Piloto do laboratório de agentes

Cérebro: `ollama:gemma3:1b` · notas: ricas · dialeto cifrado: sim · idiomas: pt, en, zh, hi, ar · duração: 5.0 min · chamadas: 3394 (0 falhas) · latência média: 0.09 s · tokens: 1244586 de entrada, 32133 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.31 | 0.40 | 0.08 |
| en | 0.37 | 0.38 | 0.00 |
| zh | 0.32 | 0.35 | 0.03 |
| hi | 0.37 | 0.40 | 0.03 |
| ar | 0.30 | 0.33 | 0.04 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.29 | 0.29 | 0.01 |
| engenharia de software | 0.37 | 0.43 | 0.06 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.05 | 0.93 | 0.02 |
| en | 0.06 | 0.90 | 0.05 |
| zh | 0.07 | 0.89 | 0.04 |
| hi | 0.18 | 0.80 | 0.02 |
| ar | 0.11 | 0.88 | 0.02 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.46 | 0.50 | 0.04 | 975 |
| bug | 0.27 | 0.37 | 0.10 | 105 |
| parsons | 0.00 | 0.00 | 0.00 | 210 |
| sort | 0.00 | 0.00 | 0.00 | 135 |

0 de 95 itens já são acertados em 95% das vezes sem notas. 16 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v3, c4, c5, k3, r2, r4, q1, a4, g1, d1, d2, d5, m2, u5, q10, g11.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.729 | 0.111 | 0.07 | 0.11 | 0.709 |
| IRT | 0.794 | 0.095 | 0.08 | 0.06 | 0.768 |
| BKT | 0.644 | 0.179 | 0.08 | 0.24 | 0.612 |
| PFA | 0.398 | 0.209 | -0.17 | 0.21 | 0.477 |
| AFM | 0.293 | 0.565 | -0.14 | 0.68 | 0.480 |

**Só nos itens informativos** (51 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.637 | 0.189 | -0.10 | 0.13 |
| IRT | 0.630 | 0.196 | -0.16 | 0.13 |
| BKT | 0.583 | 0.178 | 0.10 | 0.13 |
| PFA | 0.568 | 0.199 | 0.16 | 0.13 |
| AFM | 0.299 | 0.362 | 0.69 | 0.13 |

**Programação** (126 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | 0.04 | 0.14 | 0.090 |
| IRT | 0.06 | 0.15 | 0.090 |
| BKT | 0.01 | 0.32 | 0.188 |
| PFA | -0.30 | 0.13 | 0.128 |
| AFM | -0.23 | 0.75 | 0.617 |

**Engenharia de software** (266 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | 0.08 | 0.09 | 0.121 |
| IRT | 0.09 | 0.01 | 0.097 |
| BKT | 0.09 | 0.20 | 0.174 |
| PFA | -0.13 | 0.25 | 0.248 |
| AFM | -0.11 | 0.64 | 0.540 |

392 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 16.8 | 285 |
| pt | S2 | 1.00 | 0.00 | 22.4 | 210 |
| pt | S3 | 1.00 | 0.00 | 16.6 | 249 |
| en | S1 | 1.00 | 0.00 | 18.5 | 293 |
| en | S2 | 1.00 | 0.00 | 18.0 | 321 |
| en | S3 | 1.00 | 0.00 | 18.5 | 293 |
| zh | S1 | 0.96 | 0.00 | 4.5 | 92 |
| zh | S2 | 0.86 | 0.00 | 3.1 | 126 |
| zh | S3 | 0.98 | 0.00 | 3.1 | 47 |
| hi | S1 | 0.95 | 0.00 | 17.7 | 223 |
| hi | S2 | 0.95 | 0.00 | 18.9 | 261 |
| hi | S3 | 0.99 | 0.00 | 15.4 | 200 |
| ar | S1 | 0.99 | 0.00 | 16.4 | 180 |
| ar | S2 | 0.97 | 0.13 | 18.3 | 183 |
| ar | S3 | 1.00 | 0.00 | 16.1 | 127 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 1.0 | 249863 | 6313 | 1.09× |
| en | 666 | 1.0 | 230126 | 6001 | 1.00× |
| zh | 682 | 1.0 | 233410 | 6836 | 1.01× |
| hi | 682 | 1.0 | 261812 | 6485 | 1.14× |
| ar | 682 | 1.0 | 269375 | 6498 | 1.17× |

## 5. Projeção para o estudo completo

Com a latência medida (0.09 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
