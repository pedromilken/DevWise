# Piloto do laboratório de agentes

Cérebro: `ollama:qwen3:1.7b` · notas: ricas · dialeto cifrado: não · idiomas: pt, en, zh, hi, ar · duração: 5.1 min · chamadas: 3394 (0 falhas) · latência média: 0.09 s · tokens: 1534714 de entrada, 32658 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.64 | 0.64 | 0.00 |
| en | 0.64 | 0.65 | 0.01 |
| zh | 0.64 | 0.65 | 0.01 |
| hi | 0.51 | 0.58 | 0.07 |
| ar | 0.55 | 0.60 | 0.04 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.55 | 0.54 | -0.01 |
| engenharia de software | 0.63 | 0.68 | 0.06 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.98 | 0.00 | 0.02 |
| en | 0.99 | 0.00 | 0.01 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 1.00 | 0.00 | 0.00 |
| ar | 0.99 | 0.00 | 0.01 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.74 | 0.78 | 0.04 | 975 |
| bug | 0.63 | 0.69 | 0.06 | 105 |
| parsons | 0.14 | 0.11 | -0.03 | 210 |
| sort | 0.21 | 0.20 | -0.01 | 135 |

14 de 95 itens já são acertados em 95% das vezes sem notas. 14 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): l3, q1, q2, q3, q4, a3, g5, t2, m5, u2, o3, o4, v8, c8.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.723 | 0.168 | -0.21 | 0.04 | 0.743 |
| IRT | 0.799 | 0.166 | -0.23 | -0.06 | 0.826 |
| BKT | 0.630 | 0.216 | -0.18 | 0.18 | 0.635 |
| PFA | 0.365 | 0.341 | -0.43 | 0.21 | 0.516 |
| AFM | 0.277 | 0.476 | -0.46 | 0.42 | 0.405 |

**Só nos itens informativos** (55 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.693 | 0.191 | 0.02 | 0.22 |
| IRT | 0.660 | 0.233 | -0.07 | 0.22 |
| BKT | 0.732 | 0.162 | 0.09 | 0.22 |
| PFA | 0.623 | 0.257 | 0.26 | 0.22 |
| AFM | 0.511 | 0.268 | 0.49 | 0.22 |

**Programação** (119 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.19 | 0.09 | 0.149 |
| IRT | -0.23 | 0.04 | 0.146 |
| BKT | -0.14 | 0.23 | 0.201 |
| PFA | -0.45 | 0.32 | 0.339 |
| AFM | -0.50 | 0.54 | 0.544 |

**Engenharia de software** (269 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.21 | 0.01 | 0.177 |
| IRT | -0.23 | -0.11 | 0.176 |
| BKT | -0.19 | 0.16 | 0.223 |
| PFA | -0.43 | 0.16 | 0.342 |
| AFM | -0.44 | 0.37 | 0.446 |

388 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.38 | 17.3 | 160 |
| pt | S2 | 1.00 | 0.25 | 23.6 | 151 |
| pt | S3 | 1.00 | 0.00 | 19.5 | 172 |
| en | S1 | 1.00 | 0.13 | 21.4 | 139 |
| en | S2 | 1.00 | 0.00 | 23.4 | 113 |
| en | S3 | 1.00 | 0.13 | 21.4 | 139 |
| zh | S1 | 0.93 | 0.00 | 4.3 | 36 |
| zh | S2 | 0.88 | 0.13 | 4.9 | 51 |
| zh | S3 | 0.94 | 0.00 | 5.4 | 41 |
| hi | S1 | 0.99 | 0.25 | 16.6 | 92 |
| hi | S2 | 0.99 | 0.13 | 16.6 | 124 |
| hi | S3 | 0.99 | 0.00 | 16.8 | 163 |
| ar | S1 | 0.97 | 0.13 | 17.9 | 99 |
| ar | S2 | 0.97 | 0.25 | 23.1 | 113 |
| ar | S3 | 0.99 | 0.00 | 18.1 | 120 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 0.9 | 246814 | 6586 | 1.16× |
| en | 666 | 0.8 | 212214 | 5783 | 1.00× |
| zh | 682 | 0.9 | 222966 | 5883 | 1.05× |
| hi | 682 | 1.5 | 585957 | 8229 | 2.76× |
| ar | 682 | 0.9 | 266763 | 6177 | 1.26× |

## 5. Projeção para o estudo completo

Com a latência medida (0.09 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
