# Piloto do laboratório de agentes

Cérebro: `ollama:llama3.2:1b` · notas: ricas · dialeto cifrado: sim · idiomas: pt, en, zh, hi, ar · duração: 3.7 min · chamadas: 3394 (0 falhas) · latência média: 0.07 s · tokens: 1440823 de entrada, 38360 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.26 | 0.26 | -0.01 |
| en | 0.28 | 0.26 | -0.02 |
| zh | 0.24 | 0.30 | 0.06 |
| hi | 0.21 | 0.27 | 0.06 |
| ar | 0.19 | 0.24 | 0.05 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.20 | 0.19 | -0.01 |
| engenharia de software | 0.26 | 0.32 | 0.06 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.22 | 0.78 | 0.00 |
| en | 0.24 | 0.76 | 0.00 |
| zh | 0.12 | 0.88 | 0.00 |
| hi | 0.03 | 0.96 | 0.01 |
| ar | 0.11 | 0.89 | 0.01 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.32 | 0.37 | 0.05 | 975 |
| bug | 0.10 | 0.10 | -0.01 | 105 |
| parsons | 0.02 | 0.00 | -0.02 | 210 |
| sort | 0.03 | 0.01 | -0.02 | 135 |

0 de 95 itens já são acertados em 95% das vezes sem notas. 13 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v4, q1, q3, a2, a5, t4, t5, d1, m2, u1, u2, o1, q11.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.744 | 0.071 | 0.16 | 0.11 | 0.761 |
| IRT | 0.769 | 0.062 | 0.16 | 0.10 | 0.779 |
| BKT | 0.652 | 0.132 | 0.16 | 0.25 | 0.655 |
| PFA | 0.442 | 0.146 | -0.08 | 0.16 | 0.499 |
| AFM | 0.367 | 0.569 | -0.06 | 0.73 | 0.469 |

**Só nos itens informativos** (27 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.580 | 0.102 | -0.15 | 0.22 |
| IRT | 0.593 | 0.110 | -0.18 | 0.22 |
| BKT | 0.437 | 0.093 | 0.12 | 0.22 |
| PFA | 0.723 | 0.125 | 0.11 | 0.22 |
| AFM | 0.670 | 0.165 | 0.70 | 0.22 |

**Programação** (98 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | 0.23 | 0.07 | 0.066 |
| IRT | 0.24 | 0.11 | 0.068 |
| BKT | 0.21 | 0.21 | 0.118 |
| PFA | -0.08 | -0.01 | 0.110 |
| AFM | -0.04 | 0.66 | 0.459 |

**Engenharia de software** (268 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | 0.13 | 0.13 | 0.073 |
| IRT | 0.13 | 0.10 | 0.059 |
| BKT | 0.15 | 0.26 | 0.138 |
| PFA | -0.08 | 0.22 | 0.159 |
| AFM | -0.07 | 0.75 | 0.609 |

366 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 17.3 | 329 |
| pt | S2 | 1.00 | 0.00 | 15.3 | 299 |
| pt | S3 | 1.00 | 0.00 | 16.7 | 251 |
| en | S1 | 1.00 | 0.00 | 17.7 | 402 |
| en | S2 | 1.00 | 0.00 | 19.2 | 500 |
| en | S3 | 1.00 | 0.00 | 17.7 | 402 |
| zh | S1 | 0.95 | 0.63 | 4.8 | 92 |
| zh | S2 | 0.96 | 0.00 | 4.4 | 120 |
| zh | S3 | 0.83 | 0.00 | 3.2 | 123 |
| hi | S1 | 0.99 | 0.00 | 15.4 | 214 |
| hi | S2 | 0.95 | 0.00 | 20.0 | 310 |
| hi | S3 | 0.88 | 0.00 | 12.8 | 394 |
| ar | S1 | 0.98 | 0.13 | 12.9 | 144 |
| ar | S2 | 0.97 | 0.00 | 15.6 | 171 |
| ar | S3 | 0.76 | 0.00 | 11.4 | 254 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 0.7 | 271416 | 7861 | 1.18× |
| en | 666 | 0.6 | 230681 | 6194 | 1.00× |
| zh | 682 | 0.7 | 258451 | 7503 | 1.12× |
| hi | 682 | 0.9 | 389867 | 9790 | 1.69× |
| ar | 682 | 0.7 | 290408 | 7012 | 1.26× |

## 5. Projeção para o estudo completo

Com a latência medida (0.07 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
