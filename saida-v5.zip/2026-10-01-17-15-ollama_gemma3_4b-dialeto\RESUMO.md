# Piloto do laboratório de agentes

Cérebro: `ollama:gemma3:4b` · notas: ricas · dialeto cifrado: sim · idiomas: pt, en, zh, hi, ar · duração: 10.3 min · chamadas: 3394 (0 falhas) · latência média: 0.18 s · tokens: 1235129 de entrada, 33328 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.60 | 0.67 | 0.07 |
| en | 0.60 | 0.73 | 0.13 |
| zh | 0.58 | 0.70 | 0.12 |
| hi | 0.53 | 0.64 | 0.12 |
| ar | 0.47 | 0.66 | 0.19 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.38 | 0.53 | 0.15 |
| engenharia de software | 0.69 | 0.79 | 0.11 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.88 | 0.12 | 0.00 |
| en | 1.00 | 0.00 | 0.00 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 0.80 | 0.20 | 0.00 |
| ar | 1.00 | 0.00 | 0.00 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.69 | 0.79 | 0.11 | 975 |
| bug | 0.44 | 0.71 | 0.28 | 105 |
| parsons | 0.20 | 0.25 | 0.05 | 210 |
| sort | 0.27 | 0.53 | 0.27 | 135 |

21 de 95 itens já são acertados em 95% das vezes sem notas. 30 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v3, v4, c1, c2, c4, c5, l2, l5, f2, f5, k1, r3, q1, q5, t3, t5, d1, d3, d4, d5, q6, m2, m3, m5, u5, o2, v8, c7, c8, q7.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.661 | 0.174 | -0.24 | 0.00 | 0.750 |
| IRT | 0.825 | 0.180 | -0.27 | -0.14 | 0.842 |
| BKT | 0.566 | 0.222 | -0.22 | 0.15 | 0.700 |
| PFA | 0.386 | 0.315 | -0.47 | 0.18 | 0.566 |
| AFM | 0.290 | 0.389 | -0.50 | 0.26 | 0.351 |

**Só nos itens informativos** (87 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.668 | 0.182 | 0.01 | 0.10 |
| IRT | 0.743 | 0.211 | -0.08 | 0.10 |
| BKT | 0.634 | 0.199 | 0.15 | 0.10 |
| PFA | 0.402 | 0.280 | 0.38 | 0.10 |
| AFM | 0.297 | 0.344 | 0.52 | 0.10 |

**Programação** (107 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.07 | 0.08 | 0.134 |
| IRT | -0.07 | -0.00 | 0.124 |
| BKT | -0.13 | 0.23 | 0.201 |
| PFA | -0.37 | 0.30 | 0.308 |
| AFM | -0.35 | 0.54 | 0.505 |

**Engenharia de software** (251 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.27 | -0.03 | 0.191 |
| IRT | -0.31 | -0.21 | 0.204 |
| BKT | -0.24 | 0.10 | 0.230 |
| PFA | -0.50 | 0.11 | 0.318 |
| AFM | -0.54 | 0.11 | 0.339 |

358 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 20.8 | 237 |
| pt | S2 | 1.00 | 0.00 | 21.6 | 238 |
| pt | S3 | 1.00 | 0.00 | 21.2 | 252 |
| en | S1 | 1.00 | 0.00 | 21.9 | 231 |
| en | S2 | 1.00 | 0.00 | 23.4 | 231 |
| en | S3 | 1.00 | 0.00 | 21.9 | 231 |
| zh | S1 | 0.96 | 0.00 | 4.8 | 82 |
| zh | S2 | 0.99 | 0.00 | 4.6 | 73 |
| zh | S3 | 0.97 | 0.00 | 6.5 | 75 |
| hi | S1 | 0.96 | 0.00 | 17.6 | 215 |
| hi | S2 | 0.97 | 0.00 | 16.7 | 212 |
| hi | S3 | 1.00 | 0.00 | 16.8 | 275 |
| ar | S1 | 0.98 | 0.00 | 16.0 | 175 |
| ar | S2 | 0.99 | 0.00 | 14.4 | 192 |
| ar | S3 | 1.00 | 0.00 | 15.1 | 206 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 2.1 | 248742 | 6873 | 1.08× |
| en | 666 | 1.9 | 230076 | 6230 | 1.00× |
| zh | 682 | 2.0 | 231040 | 6626 | 1.00× |
| hi | 682 | 2.1 | 260499 | 6827 | 1.13× |
| ar | 682 | 2.2 | 264772 | 6772 | 1.15× |

## 5. Projeção para o estudo completo

Com a latência medida (0.18 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
