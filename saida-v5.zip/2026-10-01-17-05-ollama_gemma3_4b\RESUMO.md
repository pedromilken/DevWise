# Piloto do laboratório de agentes

Cérebro: `ollama:gemma3:4b` · notas: ricas · dialeto cifrado: não · idiomas: pt, en, zh, hi, ar · duração: 10.1 min · chamadas: 3394 (0 falhas) · latência média: 0.18 s · tokens: 1157163 de entrada, 32260 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.60 | 0.69 | 0.09 |
| en | 0.69 | 0.73 | 0.05 |
| zh | 0.63 | 0.71 | 0.08 |
| hi | 0.56 | 0.71 | 0.15 |
| ar | 0.53 | 0.71 | 0.18 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.50 | 0.58 | 0.08 |
| engenharia de software | 0.68 | 0.80 | 0.13 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.86 | 0.14 | 0.00 |
| en | 1.00 | 0.00 | 0.00 |
| zh | 1.00 | 0.00 | 0.00 |
| hi | 0.79 | 0.21 | 0.00 |
| ar | 1.00 | 0.00 | 0.00 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.72 | 0.81 | 0.09 | 975 |
| bug | 0.68 | 0.89 | 0.21 | 105 |
| parsons | 0.22 | 0.27 | 0.05 | 210 |
| sort | 0.27 | 0.53 | 0.26 | 135 |

21 de 95 itens já são acertados em 95% das vezes sem notas. 27 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v1, c1, c4, l2, l3, f2, k2, q5, g2, t4, t5, d1, d3, d4, d5, q6, a6, d6, m2, m3, m5, u5, v6, c7, c10, q7, g9.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.631 | 0.186 | -0.25 | 0.03 | 0.648 |
| IRT | 0.751 | 0.188 | -0.28 | -0.12 | 0.726 |
| BKT | 0.530 | 0.246 | -0.22 | 0.19 | 0.540 |
| PFA | 0.346 | 0.363 | -0.49 | 0.23 | 0.466 |
| AFM | 0.303 | 0.411 | -0.53 | 0.28 | 0.370 |

**Só nos itens informativos** (94 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.606 | 0.173 | 0.08 | 0.15 |
| IRT | 0.623 | 0.207 | -0.03 | 0.15 |
| BKT | 0.655 | 0.197 | 0.19 | 0.15 |
| PFA | 0.517 | 0.249 | 0.40 | 0.15 |
| AFM | 0.473 | 0.289 | 0.47 | 0.15 |

**Programação** (144 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.08 | 0.15 | 0.168 |
| IRT | -0.10 | 0.06 | 0.142 |
| BKT | -0.04 | 0.34 | 0.276 |
| PFA | -0.37 | 0.41 | 0.409 |
| AFM | -0.39 | 0.51 | 0.473 |

**Engenharia de software** (248 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | -0.30 | -0.06 | 0.196 |
| IRT | -0.33 | -0.24 | 0.215 |
| BKT | -0.27 | 0.08 | 0.229 |
| PFA | -0.53 | 0.10 | 0.336 |
| AFM | -0.56 | 0.12 | 0.375 |

392 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 22.3 | 235 |
| pt | S2 | 1.00 | 0.00 | 21.6 | 234 |
| pt | S3 | 1.00 | 0.00 | 24.5 | 252 |
| en | S1 | 1.00 | 0.00 | 23.3 | 254 |
| en | S2 | 1.00 | 0.00 | 25.3 | 258 |
| en | S3 | 1.00 | 0.00 | 23.3 | 254 |
| zh | S1 | 0.96 | 0.00 | 6.2 | 87 |
| zh | S2 | 0.93 | 0.00 | 5.4 | 80 |
| zh | S3 | 0.97 | 0.00 | 5.9 | 71 |
| hi | S1 | 0.98 | 0.13 | 15.1 | 221 |
| hi | S2 | 1.00 | 0.13 | 15.9 | 220 |
| hi | S3 | 1.00 | 0.00 | 14.2 | 259 |
| ar | S1 | 1.00 | 0.00 | 18.7 | 169 |
| ar | S2 | 1.00 | 0.00 | 19.6 | 180 |
| ar | S3 | 0.99 | 0.00 | 17.7 | 188 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 2.1 | 230865 | 6693 | 1.09× |
| en | 666 | 1.8 | 212560 | 5804 | 1.00× |
| zh | 682 | 2.0 | 217129 | 6387 | 1.02× |
| hi | 682 | 2.1 | 243220 | 6752 | 1.14× |
| ar | 682 | 2.1 | 253389 | 6624 | 1.19× |

## 5. Projeção para o estudo completo

Com a latência medida (0.18 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
