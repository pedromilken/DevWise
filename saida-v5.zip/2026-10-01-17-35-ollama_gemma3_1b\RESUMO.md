# Piloto do laboratório de agentes

Cérebro: `ollama:gemma3:1b` · notas: ricas · dialeto cifrado: não · idiomas: pt, en, zh, hi, ar · duração: 4.8 min · chamadas: 3394 (0 falhas) · latência média: 0.09 s · tokens: 1166857 de entrada, 30820 de saída

## 1. Aprendizes: vazamento e efeito das notas (C0 e C1)

C0 é a taxa de acerto sem notas: o quanto o cérebro já sabe sozinho. Se ficar perto de C1, as notas não fazem diferença e o degrau da C2 fica invisível.

| Idioma | C0 sem notas | C1 com notas | Ganho |
|---|---|---|---|
| pt | 0.35 | 0.36 | 0.00 |
| en | 0.35 | 0.37 | 0.02 |
| zh | 0.28 | 0.32 | 0.04 |
| hi | 0.36 | 0.37 | 0.01 |
| ar | 0.34 | 0.32 | -0.02 |

**Por área** (com o dialeto ligado, programação é onde as notas ensinam o vocabulário; engenharia de software fica como controle):

| Área | C0 | C1 | Ganho |
|---|---|---|---|
| programação | 0.29 | 0.23 | -0.06 |
| engenharia de software | 0.37 | 0.43 | 0.06 |

**Conformidade de formato**: fração das respostas que vieram no formato pedido (`ANSWER: ...`). Abaixo de 1, o corretor tolerante entendeu o resto; "ilegível" é o que nem ele entendeu e conta como erro. Seguir instruções pior num idioma também é desigualdade.

| Idioma | No formato | Tolerado | Ilegível |
|---|---|---|---|
| pt | 0.05 | 0.92 | 0.02 |
| en | 0.06 | 0.91 | 0.03 |
| zh | 0.04 | 0.92 | 0.03 |
| hi | 0.18 | 0.79 | 0.02 |
| ar | 0.11 | 0.86 | 0.03 |

**Por tipo de item** (todos os idiomas):

| Tipo | C0 | C1 | Ganho | n |
|---|---|---|---|---|
| mc | 0.46 | 0.50 | 0.04 | 975 |
| bug | 0.22 | 0.02 | -0.20 | 105 |
| parsons | 0.03 | 0.01 | -0.01 | 210 |
| sort | 0.00 | 0.00 | 0.00 | 135 |

0 de 95 itens já são acertados em 95% das vezes sem notas. 17 itens são **informativos** (as notas sobem o acerto em 0,2 ou mais): v1, k3, q1, q3, a1, a2, a4, g5, d1, d4, d5, m2, u1, u4, u5, q10, g10.

## 2. Os modelos de KT na partida real (C2) e embaralhada (C3)

`p_true` é a taxa de acerto medida do mesmo item na condição em que o agente estava (C0 antes do degrau, C1 depois). Brier contra a verdade mede se o modelo acompanha o conhecimento real; AUC mede se separa acertos de erros. Viés = previsão menos a verdade do mesmo item, nos tickets 1–3 e 4+ de cada habilidade: o ideal é chegar a zero depois do degrau; positivo é aprendizagem fantasma (prever mais acerto do que existe). C3 refaz o replay com a ordem das respostas embaralhada dentro do estudante.

| Modelo | AUC (respostas) | Brier vs verdade | Viés antes do degrau | Viés depois | AUC embaralhado (C3) |
|---|---|---|---|---|---|
| ELO | 0.712 | 0.098 | 0.12 | 0.14 | 0.742 |
| IRT | 0.780 | 0.080 | 0.11 | 0.10 | 0.762 |
| BKT | 0.659 | 0.164 | 0.15 | 0.26 | 0.620 |
| PFA | 0.332 | 0.227 | -0.11 | 0.29 | 0.410 |
| AFM | 0.292 | 0.582 | -0.10 | 0.70 | 0.522 |

**Só nos itens informativos** (59 linhas), onde o degrau existe de fato:

| Modelo | AUC | Brier vs verdade | Δ previsto | Δ verdadeiro |
|---|---|---|---|---|
| ELO | 0.482 | 0.135 | -0.08 | 0.22 |
| IRT | 0.490 | 0.136 | -0.11 | 0.22 |
| BKT | 0.495 | 0.130 | 0.02 | 0.22 |
| PFA | 0.416 | 0.134 | 0.22 | 0.22 |
| AFM | 0.412 | 0.257 | 0.64 | 0.22 |

**Programação** (127 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | 0.32 | 0.17 | 0.105 |
| IRT | 0.26 | 0.17 | 0.096 |
| BKT | 0.42 | 0.32 | 0.222 |
| PFA | 0.02 | 0.30 | 0.212 |
| AFM | -0.04 | 0.74 | 0.622 |

**Engenharia de software** (268 linhas): viés antes → depois do degrau

| Modelo | Antes | Depois | Brier vs verdade |
|---|---|---|---|
| ELO | 0.06 | 0.12 | 0.094 |
| IRT | 0.07 | 0.06 | 0.073 |
| BKT | 0.08 | 0.23 | 0.137 |
| PFA | -0.15 | 0.29 | 0.234 |
| AFM | -0.12 | 0.69 | 0.564 |

395 linhas da partida com verdade medida.

## 3. Tutores: três estratégias de localização

Escrita: fração das letras no sistema de escrita do idioma (1,0 = todo o texto na escrita certa). Vazamento: a dica contém a resposta certa. chrF contra a dica de referência do jogo (nos idiomas gerados por máquina, a referência também é tradução, então serve para comparar estratégias entre si, não como nota absoluta).

| Idioma | Estratégia | Escrita | Vazamento | chrF | Caracteres |
|---|---|---|---|---|---|
| pt | S1 | 1.00 | 0.00 | 17.5 | 267 |
| pt | S2 | 1.00 | 0.25 | 17.0 | 217 |
| pt | S3 | 1.00 | 0.00 | 16.8 | 249 |
| en | S1 | 1.00 | 0.00 | 22.4 | 275 |
| en | S2 | 1.00 | 0.13 | 19.3 | 322 |
| en | S3 | 1.00 | 0.00 | 22.4 | 275 |
| zh | S1 | 0.96 | 0.00 | 4.1 | 77 |
| zh | S2 | 0.92 | 0.00 | 3.8 | 111 |
| zh | S3 | 0.77 | 0.00 | 2.3 | 61 |
| hi | S1 | 0.99 | 0.00 | 16.9 | 235 |
| hi | S2 | 0.97 | 0.13 | 16.2 | 238 |
| hi | S3 | 1.00 | 0.00 | 15.4 | 178 |
| ar | S1 | 1.00 | 0.00 | 16.0 | 165 |
| ar | S2 | 0.87 | 0.00 | 13.4 | 163 |
| ar | S3 | 0.88 | 0.00 | 13.7 | 123 |

## 4. Custo por idioma (QP4)

Mesmas tarefas em todos os idiomas: diferenças de tempo e de tokens são o custo do idioma para este cérebro.

| Idioma | Chamadas | Minutos | Tokens de entrada | Tokens de saída | Entrada relativa à base (inglês, ou o 1º idioma) |
|---|---|---|---|---|---|
| pt | 682 | 1.0 | 235202 | 6303 | 1.10× |
| en | 666 | 0.9 | 214718 | 5978 | 1.00× |
| zh | 682 | 1.0 | 216790 | 6460 | 1.01× |
| hi | 682 | 1.0 | 246269 | 6259 | 1.15× |
| ar | 682 | 1.0 | 253878 | 5820 | 1.18× |

## 5. Projeção para o estudo completo

Com a latência medida (0.09 s por chamada), o estudo completo com este cérebro (~28 mil chamadas, 20 idiomas) levaria cerca de **1 horas** de máquina.

## Limites deste piloto

- Notas recuperadas pela habilidade do ticket (recuperação por etiqueta), não por similaridade; o estudo completo usa embeddings multilíngues.
- Exercícios de código livre e desafios extras ficaram fora da medição C0/C1; na partida, código é escrito em JavaScript e executado num contexto isolado.
- S1 usa instruções em inglês com conteúdo e resposta no idioma-alvo; o prompt inteiramente nativo pede modelos de instrução traduzidos e revisados.
- Agentes não cansam, não esquecem e já sabem programação: isto valida instrumentos de medida, não substitui aprendizes reais (Fase 5).
